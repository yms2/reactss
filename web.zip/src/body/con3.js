
import React, { Component } from "react";
import './style.css';
import './con3.css';
class Con3 extends React.Component{
    constructor(props) {
      super();
  
      this.state = {
        menu: 0,
      };
    }

    render(){
        return(
            <div className="con3_c">
              <div className="icon">
              <img src="https://images.samsung.com/kdp/cms_contents/136790/84aef074-bcd0-4b96-a522-d4c5f2d7449a.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/136790/84aef074-bcd0-4b96-a522-d4c5f2d7449a.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/136790/a195c4d2-3d55-41a4-a12a-4c9b86b23714.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/136790/724335d0-db70-4f7a-b7cf-9b0ecfedfe2b.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/c51dcbb0-f2af-4b4d-bc03-984d7d457556.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/9f39b941-e787-4326-9daf-c9526d627d14.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/cbb620bd-ef9c-4263-8608-b9cc7f015394.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/53efff1b-58ba-405f-892e-52fac9ba29fb.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/efde9c24-78f8-45f7-a6eb-01d66b7385c5.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/26c06fe9-fdc1-4b1c-a8e2-675c501fed1c.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/5a792b2e-c81d-4656-8a24-7fb28eb26109.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/ef8d40d1-9e51-48a2-a7f1-a420c57ed3b7.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/163216/5c91a15a-0627-4a0e-9e82-3709051dea2d.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/161260/8418b574-273e-4273-ac55-557e69002d2d.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/161260/364ae3c5-76c1-4ae1-b2b9-6066529316db.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/136790/ff9491eb-716d-4046-a3dc-35bed7d3dd28.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/136790/2683ea54-20b5-491d-a198-2bd97eaa514d.png?$240_240_PNG$"/>
              <img src="https://images.samsung.com/kdp/cms_contents/136790/5eb24745-f70d-4c1f-8117-c14658bcc57b.png?$240_240_PNG$"/>
              </div>
            </div>
        )
    }
  }
  
  
  export default Con3;